const User = require("../model/User");
// const bcrypt = require('bcrypt');

const handleNewUser = async (req, res) => {
  const { userId, firstName, lastName, phoneNumber, CNIC, email, passport, bachelor } =
    req.body;

  // Validate required fields
  if (
    !userId,
    !firstName ||
    !lastName ||
    !phoneNumber ||
    !CNIC ||
    !email ||
    !passport ||
    !bachelor
  )
    return res.status(400).json({ message: "All fields are required." });

  // Check for duplicate CNIC in the database
  const duplicate = await User.findOne({ CNIC }).exec();
  if (duplicate) return res.sendStatus(409); // Conflict

  try {
    // Encrypt the password (if you add password functionality later)
    // const hashedPwd = await bcrypt.hash(pwd, 10);

    // Create and store the new user
    const result = await User.create({
      userId,
      firstName,
      lastName,
      phoneNumber,
      CNIC,
      email,
      passport,
      bachelor,
    });

    console.log(result);

    // Send a response indicating success
    res
      .status(201)
      .json({ success: `New user ${firstName} ${lastName} created!` });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { handleNewUser };
