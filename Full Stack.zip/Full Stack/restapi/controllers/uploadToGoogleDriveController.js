const { google } = require("googleapis");
const fs = require("fs");

const uploadToGoogleDrive = async (file, auth) => {
  try {
    // Ensure file.path is valid
    if (!file.path || !fs.existsSync(file.path)) {
      throw new Error(`File not found: ${file.path}`);
    }

    const fileMetadata = {
      name: file.originalname,
      parents: ["18iTfeRJ8g4VVcrkTKqxSKdNZ0dIKHI8B"], // Ensure this ID is valid and exists in Google Drive
    };

    const media = {
      mimeType: file.mimetype,
      body: fs.createReadStream(file.path),
    };

    const driveService = google.drive({ version: "v3", auth });

    // Upload the file to Google Drive
    const response = await driveService.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: "id",
    });

    // Check if response is successful
    if (!response || !response.data || !response.data.id) {
      throw new Error("Failed to upload file to Google Drive. No ID returned.");
    }

    console.log("File uploaded successfully:", response.data.id); // Log the uploaded file ID
    return response;
  } catch (error) {
    console.error("Error uploading file to Google Drive:", error.message);
    throw error; // Rethrow the error for further handling
  }
};

const deleteFile = (filePath) => {
  fs.unlink(filePath, (err) => {
    if (err) {
      console.error("Error deleting file:", err.message);
    } else {
      console.log("File deleted successfully:", filePath);
    }
  });
};

module.exports = { uploadToGoogleDrive, deleteFile };
