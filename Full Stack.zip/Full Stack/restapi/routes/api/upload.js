const express = require("express");
const router = express.Router();
const authenticateGoogle = require("../../authenticateGoogle");
const uploadToGoogleDrive = require("../../controllers/uploadToGoogleDriveController");
const multer = require("../../middleware/multer");

router.post(
  "/upload-file-to-google-drive",
  multer.array("files[]"),
  async (req, res, next) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).send("No files uploaded.");
      }

      const auth = await authenticateGoogle.authenticateGoogle();

      const uploadPromises = req.files.map((file) =>
        uploadToGoogleDrive.uploadToGoogleDrive(file, auth)
      );
      const responses = await Promise.all(uploadPromises); // Wait for all uploads to finish
      // Wait for all uploads to finish

      // Optionally delete files after uploading
      req.files.forEach((file) => uploadToGoogleDrive.deleteFile(file.path));

      res.status(200).json({
        success: true,
        fileIds: responses.map((response) => response.data.id), // Array of uploaded file IDs
        message: "Files uploaded successfully.",
      });
    } catch (err) {
      console.error("Error during file upload:", err);
      res.status(500).json({
        success: false,
        message: "An error occurred during file upload.",
        error: err.message,
      });
    }
  }
);

module.exports = router;
