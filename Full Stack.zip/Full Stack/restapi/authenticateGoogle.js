const { google } = require("googleapis");
const path = require("path");

const authenticateGoogle = async () => {
  try {
    const auth = new google.auth.GoogleAuth({
      keyFile: path.join(__dirname, 'key.json'),
      scopes: ["https://www.googleapis.com/auth/drive"],
    });

    const authClient = await auth.getClient();

    return authClient;
  } catch (error) {
    console.error("Error during Google authentication:", error);
    throw new Error("Failed to authenticate with Google");
  }
};

module.exports = { authenticateGoogle };
