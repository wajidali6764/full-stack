import TabsSection from "./components/TabsSection";
import Model from "./components/ModelButton";

function App() {
  return (
    <>
      <Model />
      <TabsSection />
    </>
  );
}

export default App;
