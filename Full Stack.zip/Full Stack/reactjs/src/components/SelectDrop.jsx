import { GiSettingsKnobs } from "react-icons/gi";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import addApplicantAction from "../RTK/Actions/addApplicantAction";
import axios from "axios";
import isLoadingAction from "../RTK/Actions/isLoadingAction";

const SelectDrop = () => {
  const [selectToggle, setSelectToggle] = useState(false);
  const tableData = useSelector((state) => state.addApplicantReducer); // Access Redux state directly
  const [filteredData, setFilteredData] = useState(tableData); // For filtering purposes
  const dispatch = useDispatch();
  const userId = useSelector((state) => state.filterReducer);

  const handleClick = () => {
    setSelectToggle((prev) => !prev);
  };

  useEffect(() => {
    setFilteredData(tableData);
  }, [tableData]);

  const handleChange = async (e) => {
    const { name, value } = e.target;
    if (value === "") {
      const GET_USER = `http://localhost:3500/api/users/${userId}/employees`;
      const request = async () => {
        try {
          dispatch(isLoadingAction(true));
          const response = await axios.get(GET_USER);
          setFilteredData(response?.data);
          dispatch(addApplicantAction((response?.data).reverse()));
        } catch (err) {
          console.error(err);
        } finally {
          dispatch(isLoadingAction(false));
        }
      };
      request();
      return;
    }
    let newFilteredData;
    if (e.target.name === "firstName") {
      newFilteredData = tableData.filter((item) =>
        item[name].toLowerCase().includes(value.toLowerCase())
      );
    } else if (e.target.name === "email") {
      newFilteredData = tableData.filter((item) =>
        item[name].toLowerCase().includes(value.toLowerCase())
      );
    } else if (e.target.name === "occupation") {
      newFilteredData = tableData.filter((item) =>
        item[name].toLowerCase().includes(value.toLowerCase())
      );
    }
    setFilteredData(newFilteredData);
    dispatch(addApplicantAction(newFilteredData));
  };

  return (
    <>
      <div className="container-fluid relative cursor-pointer z-50">
        <div
          className="flex items-center justify-center px-5 py-[5px] text-gray-500 border border-blue-100 rounded-md"
          onClick={handleClick}
        >
          <span className="inline-block mr-2">
            <GiSettingsKnobs />
          </span>
          Filter
        </div>
        {selectToggle && (
          <div className="absolute top-10 right-0 px-5 py-5 shadow-lg shadow-gray-300 w-[450px] ">
            <ul className="w-full text-gray-500 font-medium text-[13px]">
              <li className="flex justify-between mb-3">
                <label htmlFor="firstName" className="tracking-wide pr-3">
                  Name
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="border px-2 py-2 rounded-sm w-[260px] outline-1 focus:outline-blue-300 font-normal"
                  placeholder="Search name"
                  onChange={handleChange}
                />
              </li>
              <li className="flex justify-between mb-3">
                <label htmlFor="email" className="tracking-wide pr-3">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  className="border px-2 py-2 rounded-sm w-[260px] outline-1 focus:outline-blue-300 font-normal"
                  placeholder="Enter email"
                  onChange={handleChange}
                />
              </li>
              <li className="flex justify-between mb-3">
                <label htmlFor="occupation" className="tracking-wide pr-3">
                  Occupation
                </label>
                <input
                  type="text"
                  name="occupation"
                  id="occupation"
                  className="border px-2 py-2 rounded-sm w-[260px] outline-1 focus:outline-blue-300 font-normal"
                  placeholder="Enter occupation"
                  onChange={handleChange}
                />
              </li>
            </ul>
          </div>
        )}
      </div>
    </>
  );
};

export default SelectDrop;
