import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./components/ui/table";
import FormModelEdit from "./EditForm/ZIREditeForm";
import { CiMenuKebab } from "react-icons/ci";
import CheckboxDemo from "./CheckboxDemo";
import CheckboxWithText from "./CheckboxWithText";
import Dumi from "./ApplicantDetial";
import { useState } from "react";
import TableLoader from "./TableLoader";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import addApplicantAction from "../RTK/Actions/addApplicantAction";
import { Statusbar } from "./Statusbar";
import isLoadingAction from "../RTK/Actions/isLoadingAction";

function ColumnView({ tableHeader, tableScheme, tableData, status }) {
  const isLoading = useSelector((state) => state.isLoadingReducer);
  const [isEdit, setIsEdit] = useState(false);
  const [values, setValues] = useState({});
  const [isModelOpen, setIsModelOpen] = useState(false);
  const [dropdownOpenRow, setDropdownOpenRow] = useState(null); // Track the row with an open dropdown
  const userId = useSelector((state) => state.filterReducer);
  const dispatch = useDispatch();

  const DeleteAction = async (emp_id) => {
    try {
      dispatch(isLoadingAction(true));
      const DELETE_EMP = `http://localhost:3500/api/users/${userId}/employees/${emp_id}`;
      await axios.delete(DELETE_EMP);
      const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
      const response = await axios.get(GET_EMP);
      dispatch(addApplicantAction((response?.data).reverse()));
    } catch (err) {
      console.error(err);
    } finally {
      dispatch(isLoadingAction(false));
    }
  };

  const EditAction = (value) => {
    setIsEdit(true);
    setValues(value);
  };

  const handleMouseClick = (rowId) => {
    setDropdownOpenRow((prev) => (prev === rowId ? null : rowId)); // Toggle dropdown for this row
  };

  const [value, setValue] = useState([
    {
      cnic: "",
      email: "",
      firstName: "",
      lastName: "",
      phoneNumber: "",
    },
  ]);

  const closeModel = () => {
    setIsModelOpen(false);
  };

  const closeEditeModel = () => {
    setIsEdit(false);
  };

  const showInfo = (e) => {
    setValue(tableData.filter((value) => value._id === e.currentTarget.id));
    setIsModelOpen(true);
  };

  return (
    <>
      <FormModelEdit isOpen={isEdit} onClose={closeEditeModel} value={values} />
      <Dumi isOpen={isModelOpen} onClose={closeModel} value={value} />

      <div className="w-full overflow-x-auto">
        {" "}
        {/* Add overflow-x-auto to allow horizontal scrolling */}
        <Table className="min-w-full table-auto">
          {" "}
          {/* Use min-w-full to make the table responsive */}
          <TableHeader>
            <TableRow>
              <TableHead className="text-right bg-[#f9fbfd] border-none font-bold tracking-wider text-[11px] text-gray-500">
                <CheckboxDemo />
              </TableHead>
              {tableHeader.map((value, index) => (
                <TableHead
                  key={index}
                  className="bg-[#f9fbfd] border-none font-bold tracking-wider text-[11px] text-gray-500"
                >
                  {value}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          {isLoading ? (
            <TableLoader />
          ) : (
            <TableBody>
              {tableData.map((value, index) => (
                <TableRow
                  key={index}
                  id={value._id}
                  className="border-none cursor-pointer bg-white hover:bg-blue-100"
                >
                  <TableCell className="font-medium bg-inherit">
                    <CheckboxDemo />
                  </TableCell>
                  {tableScheme.map((property, index) => (
                    <TableCell
                      key={index}
                      id={value._id}
                      className="font-medium text-gray-500 bg-inherit truncate"
                    >
                      {property[0] !== "status" && (
                        <span
                          onClick={showInfo}
                          id={value._id}
                          className="bg-inherit"
                        >
                          <CheckboxWithText
                            parm1={value[property[0]]}
                            parm2={value[property[1]] || ""}
                            parm3=""
                          />
                        </span>
                      )}
                      {property[0] !== "status" && (
                        <span
                          onClick={showInfo}
                          id={value._id}
                          className="bg-inherit"
                        >
                          <CheckboxWithText
                            parm1=""
                            parm2=""
                            parm3={value[property[2]]}
                          />
                        </span>
                      )}
                      {property[0] === "status" && (
                        <Statusbar emp_id={value._id} value={value} />
                      )}
                    </TableCell>
                  ))}
                  <TableCell
                    id={value._id}
                    className="text-right bg-inherit cursor-pointer relative"
                    onClick={() => handleMouseClick(value._id)} // Pass row ID
                  >
                    <CiMenuKebab className="bg-inherit" />
                    {dropdownOpenRow === value._id && ( // Check if this row's dropdown is open
                      <ul className="absolute top-[60%] right-[20px] px-[10px] py-[5px] min-w-40 rounded-lg bg-white shadow-lg shadow-gray-200 overflow-hidden min-h-0 font-[Poppins]">
                        <li
                          className="flex items-center bg-white p-[10px] rounded-[5px] hover:text-gray-300"
                          onClick={() => EditAction(value)}
                        >
                          <button className="border-none outline-none mt-1 pl-[7px] bg-transparent text-green-400 text-[15px] ">
                            Edit
                          </button>
                        </li>
                        <li
                          className="flex items-center bg-white p-[10px] rounded-[5px] hover:text-gray-300"
                          onClick={() => DeleteAction(value._id)}
                        >
                          <button className="border-none outline-none mt-1 pl-[7px] bg-transparent text-red-400 text-[15px] ">
                            Delete
                          </button>
                        </li>
                      </ul>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          )}
        </Table>
      </div>
    </>
  );
}

export default ColumnView;
