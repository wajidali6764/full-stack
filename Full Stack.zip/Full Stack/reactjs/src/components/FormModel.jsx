import addApplicantAction from "../RTK/Actions/addApplicantAction";
import { useDispatch, useSelector } from "react-redux";
import { RxCrossCircled } from "react-icons/rx";
import { useRef, useState } from "react";
import axios from "axios";
import isLoadingAction from "../RTK/Actions/isLoadingAction";

const FormModel = ({ isOpen, onClose }) => {
  const userId = useSelector((state) => state.filterReducer);
  const isLoading = useSelector((state) => state.isLoadingReducer);
  // Create a ref for the file input
  const fileInputRef = useRef(null);
  const [files, setFiles] = useState([]);
  let link = "";
  const handleClick = async () => {
    let formData = new FormData();

    // Append each file to the FormData object
    files.forEach((file) => {
      formData.append("files[]", file.data); // Ensure the name matches what your server expects
    });

    try {
      const response = await axios.post(
        "http://localhost:3500/api/upload/upload-file-to-google-drive",
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" }, // Set content type for multipart form data
        }
      );
      link = JSON.stringify(...response?.data?.fileIds);
    } catch (err) {
      console.error(err);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setFiles([]);
  };

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files); // Convert FileList to array

    const filesWithPreview = selectedFiles.map((file) => ({
      preview: URL.createObjectURL(file), // Generate preview URL
      data: file, // Store the file object
    }));

    setFiles(filesWithPreview); // Update state with array of file objects
  };

  const dispatch = useDispatch();
  const [value, setValue] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    cnic: "",
    email: "",
    desiredCountry: "",
    // IELTS_PTE_Score: "",
    dateOfBirth: "",
    passport: "",
    occupation: "",
    region: "",
    yearsOfExperience: "",
    address: "",
    levelOfEdcuation: "",
    link: "",
    status: "Active",
  });
  const handleSubmit = async (e) => {
    e.preventDefault();
    const CREATE_EMP = `http://localhost:3500/api/users/${userId}/employees`;
    try {
      dispatch(isLoadingAction(true));
      await handleClick();
      await axios.post(
        CREATE_EMP,
        JSON.stringify({
          firstName: value.firstName,
          lastName: value.lastName,
          phoneNumber: value.phoneNumber,
          cnic: value.cnic,
          email: value.email,
          desiredCountry: value.desiredCountry,
          // IELTS_PTE_Score: value.IELTS_PTE_Score,
          dateOfBirth: value.dateOfBirth,
          passport: value.passport,
          occupation: value.occupation,
          region: value.region,
          yearsOfExperience: value.yearsOfExperience,
          address: value.address,
          levelOfEdcuation: value.levelOfEdcuation,
          link: link,
          status: value.status,
        }),
        {
          headers: { "Content-Type": "application/json" },
          withCredentials: true,
        }
      );
      const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
      const response = await axios.get(GET_EMP);
      dispatch(addApplicantAction((response?.data).reverse()));
    } catch (err) {
      if (!err?.response) {
        console.log("No Server Response");
      } else if (err.response?.status === 409) {
        console.log("Username Taken");
      } else {
        console.log("Registration Failed");
      }
    } finally {
      dispatch(isLoadingAction(false));
    }
    setValue({
      firstName: "",
      lastName: "",
      phoneNumber: "",
      cnic: "",
      email: "",
      desiredCountry: "",
      // IELTS_PTE_Score: "",
      dateOfBirth: "",
      passport: "",
      occupation: "",
      region: "",
      yearsOfExperience: "",
      address: "",
      levelOfEdcuation: "",
      link: "",
      status: "Active",
    });
    onClose();
    setFiles([]);
  };
  return (
    <>
      <div
        className={`fixed top-0 z-[500] left-0  w-full h-full flex justify-end bg-[#717D8C] bg-opacity-25 ${
          isOpen ? "" : "hidden"
        }`}
      >
        <div className="overflow-scroll fixed top-0 right-0 sidebar_animation  bg-[#F9FBFD] p-5 lg:w-[500px] md:w-[500px] sm:w-[500px] h-full rounded">
          <div className="flex justify-between border-b pb-3">
            <h3 className="font-semibold text-lg">Add Applicant</h3>
            <button
              onClick={onClose}
              className="font-semibold text-gray-400 text-[32px]"
            >
              <RxCrossCircled />
            </button>
          </div>
          <form className="mt-5 text-sm" onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="firstName">
                  First Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="Enter first name"
                  value={value.firstName}
                  onChange={(e) =>
                    setValue({ ...value, firstName: e.currentTarget.value })
                  }
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="lastName">
                  Last Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="lastName"
                  id="lastName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="Enter last name"
                  value={value.lastName}
                  onChange={(e) =>
                    setValue({ ...value, lastName: e.currentTarget.value })
                  }
                  required
                />
              </div>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="email">
                Email Address:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="email"
                id="email"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Emai@gmail.com"
                value={value.email}
                onChange={(e) =>
                  setValue({ ...value, email: e.currentTarget.value })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="phoneNumber">
                Phone Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="phoneNumber"
                id="phoneNumber"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Enter phone number"
                value={value.phoneNumber}
                onChange={(e) =>
                  setValue({ ...value, phoneNumber: e.currentTarget.value })
                }
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="address">
                Address:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>

              <input
                type="text"
                name="address"
                id="address"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Enter your address"
                required
                value={value.address}
                onChange={(e) =>
                  setValue({
                    ...value,
                    address: e.currentTarget.value,
                  })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="cnic">
                C.N.I.C Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="cnic"
                id="cnic"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="C.N.I.C Number"
                value={value.cnic}
                onChange={(e) =>
                  setValue({ ...value, cnic: e.currentTarget.value })
                }
                required
              />
            </div>

            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="desiredCountry">
                Desired Country:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="desiredCountry"
                id="desiredCountry"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={value.desiredCountry}
                onChange={(e) =>
                  setValue({
                    ...value,
                    desiredCountry: e.currentTarget.value,
                  })
                }
                placeholder="Enter desired country"
                required
              />
            </div>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="dateOfBirth">
                  Date Of Birth:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="date"
                  name="dateOfBirth"
                  id="dateOfBirth"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder=""
                  value={value.dateOfBirth}
                  onChange={(e) =>
                    setValue({
                      ...value,
                      dateOfBirth: e.currentTarget.value,
                    })
                  }
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="passport">Passport Number</label>
                <input
                  type="text"
                  name="passport"
                  id="passport"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={value.passport}
                  onChange={(e) =>
                    setValue({ ...value, passport: e.currentTarget.value })
                  }
                  placeholder="Enter passport"
                />
              </div>
            </div>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="occupation">
                  Occupation:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="occupation"
                  id="occupation"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  placeholder="Enter occupation"
                  required
                  value={value.occupation}
                  onChange={(e) =>
                    setValue({
                      ...value,
                      occupation: e.currentTarget.value,
                    })
                  }
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="region">
                  Region:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="region"
                  id="region"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={value.region}
                  onChange={(e) =>
                    setValue({ ...value, region: e.currentTarget.value })
                  }
                  placeholder="Enter region"
                  required
                />
              </div>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="yearsOfExperience">
                Years of Experience:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="yearsOfExperience"
                id="yearsOfExperience"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Enter years of experience "
                required
                value={value.yearsOfExperience}
                onChange={(e) =>
                  setValue({
                    ...value,
                    yearsOfExperience: e.currentTarget.value,
                  })
                }
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="levelOfEdcuation" className="tracking-wide">
                Highest Level Of Edcuation / Year:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="levelOfEdcuation"
                id="levelOfEdcuation"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                placeholder="Enter level of edcuation"
                required
                value={value.levelOfEdcuation}
                onChange={(e) =>
                  setValue({
                    ...value,
                    levelOfEdcuation: e.currentTarget.value,
                  })
                }
              />
            </div>

            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="file">
                CV:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="file"
                name="files"
                onChange={handleFileChange}
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                id="file"
                ref={fileInputRef}
                multiple
                required
              />

              {/* Optional: Display selected file names */}
              {files &&
                files.map((file, index) => (
                  <div key={index} className="mt-2 text-gray-700">
                    {file.data.name}
                  </div>
                ))}
            </div>

            <button
              type="submit"
              handleClick
              className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-9 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            >
              {isLoading ? "Loading..." : "Save"}
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default FormModel;
