import { useSelector } from "react-redux";
import { useState } from "react";
import { FaPlus } from "react-icons/fa6";
import TableDemo from "./TableDemo";
import FormModel from "./FormModel";

const AddApplicants = () => {
  const [isModelOpen, setIsModelOpen] = useState(false);
  const isLoading = useSelector((state) => state.isLoadingReducer);
  const openModel = () => {
    setIsModelOpen(true);
  };
  const closeModel = () => {
    setIsModelOpen(false);
  };

  const tableData = useSelector((state) => state.addApplicantReducer);
  const tableHeader = [
    "NAME",
    "PHONE NUMBER",
    "C.N.I.C Number",
    "Occupation",
    "Desired Country",
    "Status",
    " ",
  ];
  const tableScheme = [
    ["firstName", "lastName", "email"],
    ["phoneNumber"],
    ["cnic"],
    ["occupation"],
    ["desiredCountry"],
    ["status"],
  ];
  return (
    <>
      <FormModel isOpen={isModelOpen} onClose={closeModel} />
      <TableDemo
        tableHeader={tableHeader}
        tableScheme={tableScheme}
        tableData={tableData}
        isLoading={isLoading}
        status={true}
      />
      <button
        className="fixed bottom-2 right-2 md:bottom-7 md:right-2"
        onClick={openModel}
      >
        <div className="border p-4 bg-[#2C7BE5] rounded-[100%]">
          <FaPlus className="bg-[#2C7BE5] text-white text-xl font-bold" />
        </div>
      </button>
    </>
  );
};

export default AddApplicants;
