import { Avatar, AvatarImage } from "./components/ui/avatar";
import { useState } from "react";
import { PiSignOutLight } from "react-icons/pi";
import CheckboxWithText from "./CheckboxWithText";

const ProfileComponent = () => {
  const [isDropDownOpen, setIsDropDownOpen] = useState(false);

  const handleMouseClick = () => {
    setIsDropDownOpen((prev) => !prev);
  };
  return (
    <div className="bg-white relative">
      <span onClick={handleMouseClick}>
        <Avatar className="cursor-pointer">
          <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        </Avatar>
      </span>
      {isDropDownOpen && (
        <ul className="absolute top-[100%] right-[20px] z-50 px-[10px] py-[5px] min-w-60 rounded-lg bg-white shadow-lg shadow-gray-200 overflow-hidden min-h-0 dropDownMenu font-[Poppins]">
          <li className="flex items-center bg-white p-[10px] rounded-[5px] border-b border-dashed">
            <button className="border-none outline-none mt-1 pl-[7px] bg-transparent text-gray-400">
              <CheckboxWithText parm1="User" parm2="" parm3="Example1234@gmail.com" />
            </button>
          </li>
          <li className="flex items-center bg-white p-[10px] rounded-[5px] border-t border-dashed">
            <span className="text-[22px] bg-white text-gray-400">
              <PiSignOutLight className="bg-white text-red-400" />
            </span>
            <button className="border-none outline-none mt-1 pl-[7px] bg-transparent text-red-400 text-[15px] ">
              Sign Out
            </button>
          </li>
        </ul>
      )}
    </div>
  );
};

export default ProfileComponent;
