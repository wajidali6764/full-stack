import SelectDrop from "./SelectDrop";

function SelectDemo() {

  return (
    <>
      <div className="select">
        <SelectDrop />
      </div>
    </>
  );
}

export default SelectDemo;
