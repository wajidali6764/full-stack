import addApplicantAction from "../../RTK/Actions/addApplicantAction";
import { useDispatch, useSelector } from "react-redux";
import { RxCrossCircled } from "react-icons/rx";
import axios from "axios";
import { useEffect, useState } from "react";
import isLoadingAction from "../../RTK/Actions/isLoadingAction";

const FormModelEdit = ({ isOpen, onClose, value }) => {
  const userId = useSelector((state) => state.filterReducer);
  const isLoading = useSelector((state) => state.isLoadingReducer);
  const [editValues, setEditValues] = useState(value);
  const dispatch = useDispatch();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      dispatch(isLoadingAction(true));
      const EDIT_EMP = `http://localhost:3500/api/users/${userId}/employees/${value._id}`;
      await axios.put(
        EDIT_EMP,
        JSON.stringify({
          _id: editValues._id,
          firstName: editValues.firstName,
          lastName: editValues.lastName,
          phoneNumber: editValues.phoneNumber,
          cnic: editValues.cnic,
          email: editValues.email,
          country: editValues.country,
          IELTS_PTE_Score: editValues.IELTS_PTE_Score,
          dateOfBirth: editValues.dateOfBirth,
          passport: editValues.passport,
          occupation: editValues.occupation,
          region: editValues.region,
          yearsOfExperience: editValues.yearsOfExperience,
          address: editValues.address,
          levelOfEdcuation: editValues.levelOfEdcuation,
          status: editValues.status,
        }),
        {
          headers: { "Content-Type": "application/json" },
          withCredentials: true,
        }
      );
      const GET_EMP = `http://localhost:3500/api/users/${userId}/employees`;
      const response = await axios.get(GET_EMP);
      dispatch(addApplicantAction(response?.data));
    } catch (err) {
      if (!err?.response) {
        console.log("No Server Response");
      } else if (err.response?.status === 409) {
        console.log("Username Taken");
      } else {
        console.log("Registration Failed");
      }
    } finally {
      dispatch(isLoadingAction(false));
    }
    onClose();
  };

  // Sync state with the new value when the component opens or the value prop changes
  useEffect(() => {
    if (isOpen) {
      setEditValues(value);
    }
  }, [isOpen, value]);

  return (
    <>
      <div
        className={`fixed top-0 z-50 left-0  w-full h-full flex justify-end bg-[#717D8C] bg-opacity-25 ${
          isOpen ? "" : "hidden"
        }`}
      >
        <div className="overflow-scroll fixed top-0 right-0 sidebar_animation  bg-[#F9FBFD] p-5 lg:w-[500px] md:w-[500px] sm:w-[500px] h-full rounded">
          <div className="flex justify-between border-b pb-3">
            <h3 className="font-semibold text-lg">Edit Applicant</h3>
            <button
              onClick={onClose}
              className="font-semibold text-gray-400 text-[32px]"
            >
              <RxCrossCircled />
            </button>
          </div>
          <form className="mt-5 text-sm" onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="firstName">
                  First Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="firstName"
                  id="firstName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={editValues.firstName}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      ["firstName"]: e.currentTarget.value,
                    })
                  }
                  placeholder="Enter first name"
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="lastName">
                  Last Name:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="lastName"
                  id="lastName"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={editValues.lastName}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      ["lastName"]: e.currentTarget.value,
                    })
                  }
                  placeholder="Enter last name"
                  required
                />
              </div>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="email">
                Email Address:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="email"
                id="email"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.email}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["email"]: e.currentTarget.value,
                  })
                }
                placeholder="Emai@gmail.com"
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="number">
                Phone Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="phoneNumber"
                id="phoneNumber"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.phoneNumber}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["phoneNumber"]: e.currentTarget.value,
                  })
                }
                placeholder="Enter phone number"
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="address">
                Address:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>

              <input
                type="text"
                name="address"
                id="address"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.address}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    address: e.currentTarget.value,
                  })
                }
                placeholder="Enter your address"
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="cnic">
                C.N.I.C Number:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="cnic"
                id="cnic"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.cnic}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["cnic"]: e.currentTarget.value,
                  })
                }
                placeholder="C.N.I.C Number"
                required
              />
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="desiredCountry">
                Country:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="desiredCountry"
                id="desiredCountry"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.desiredCountry}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    ["desiredCountry"]: e.currentTarget.value,
                  })
                }
                placeholder="Enter desired country"
                required
              />
            </div>
            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="dateOfBirth">
                  Date Of Birth:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="date"
                  name="dateOfBirth"
                  id="dateOfBirth"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={editValues.dateOfBirth}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      ["dateOfBirth"]: e.currentTarget.value,
                    })
                  }
                  placeholder=""
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="passport">Passport Number</label>
                <input
                  type="text"
                  name="passport"
                  id="passport"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={editValues.passport}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      ["passport"]: e.currentTarget.value,
                    })
                  }
                  placeholder="Enter passport number"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 md:gap-6">
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="occupation">
                  Occupation:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="occupation"
                  id="occupation"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={editValues.occupation}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      occupation: e.currentTarget.value,
                    })
                  }
                  placeholder="Enter occupation"
                  required
                />
              </div>
              <div className="relative z-0 w-full mb-5 group">
                <label htmlFor="region">
                  Region:
                  <span className="text-red-700 text-[15px]"> *</span>
                </label>
                <input
                  type="text"
                  name="region"
                  id="region"
                  className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                  value={editValues.region}
                  onChange={(e) =>
                    setEditValues({
                      ...editValues,
                      region: e.currentTarget.value,
                    })
                  }
                  placeholder="Enter region"
                  required
                />
              </div>
            </div>
            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="yearsOfExperience">
                Years of Experience:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="yearsOfExperience"
                id="yearsOfExperience"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.yearsOfExperience}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    yearsOfExperience: e.currentTarget.value,
                  })
                }
                placeholder="Enter years of experience"
                required
              />
            </div>

            <div className="relative z-0 w-full mb-5 group">
              <label htmlFor="levelOfEdcuation" className="tracking-wide">
                Highest Level Of Edcuation / Year:
                <span className="text-red-700 text-[15px]"> *</span>
              </label>
              <input
                type="text"
                name="levelOfEdcuation"
                id="levelOfEdcuation"
                className="w-full text-gray-800 rounded-md border border-blue-100 bg-white py-3 px-6 text-base font-medium outline-none"
                value={editValues.levelOfEdcuation}
                onChange={(e) =>
                  setEditValues({
                    ...editValues,
                    levelOfEdcuation: e.currentTarget.value,
                  })
                }
                placeholder="Enter level of edcuation"
                required
              />
            </div>
            <button
              type="submit"
              className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-9 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
            >
              {isLoading ? "Loading..." : "Save Edit"}
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default FormModelEdit;
